import React, { Component } from 'react'


class Login extends Component {
    constructor() {
        super();
        this.state = {
            form: {
                emailId: "",
                password: "",
                username: "",

            },
            formErrorMessage: {
                emailId: "",
                password: "",
                username: "",
            },
            formValid: {
                emailId: false,
                password: false,
                username: false,
                buttonActive: false
            },
            successMessage: "",
            errorMessage: ""
        }
    }

    handleChange = (event) => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const { form } = this.state;

        this.setState({ form: { ...form, [name]: value } });
        this.validateField(name, value);
    }

    validateField = (name, value) => {
        let tempValid = this.state.formValid;
        let tempError = this.state.formErrorMessage;
        let stringVal = String(value);
        switch (name) {
            case "emailId":

                if (value === "") {
                    tempError.emailId = "Field required"
                    tempValid.emailId = false
                }
                else if (!stringVal.match(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/)) {
                    tempValid.emailId = false;
                    tempError.emailId = "Please enter valid email";
                }
                else {
                    tempValid.emailId = true;
                    tempError.emailId = " ";
                }
                break;
            case "password":
                if (value === "") {
                    tempError.password = "Field required";
                    tempValid.password = false;
                }
                else if (stringVal.length <= 6) {
                    tempError.password = "password too short";
                    tempValid.password = false;
                }
                else {
                    tempError.password = "";
                    tempValid.password = true;
                }
                break;
            default:
                break;
        }
        tempValid.buttonActive = tempValid.emailId

        this.setState({ formErrorMessage: tempError, formValid: tempValid, successMessage: ' ' })

    }



    render = () => {
        return (
            <React.Fragment>
                <div className="Login ">
                    <div className="container-fluid row">
                        <div className="col-md-6 offset-md-3">
                            <br />
                            <div className="card">
                                <div className="card-header bg-custom">
                                    <img className="card-img-top" src="C:\Users\raghav11.trn\Desktop\chat\chat-app\src\assets\eye.png" alt="card header image" />
                                </div>
                                <div className="card-body">
                                    <form>
                                        <div className="form-group">
                                            <label htmlFor="emailId">Email Id </label>
                                            <input
                                                type="email"
                                                name="emailId"
                                                id="emailId"
                                                placeholder="Enter your email"
                                                onChange={this.handleChange}
                                                className="form-control"
                                            />

                                            <span name="emailIdError" className="text-danger">
                                                {this.state.formErrorMessage.emailId}
                                            </span>
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="password">Password </label>
                                            <input
                                                type="password"
                                                name="password"
                                                id="password"
                                                placeholder="Enter your password"
                                                onChange={this.handleChange}
                                                className="form-control"
                                            />

                                            <span name="paswordError" className="text-danger">
                                                {this.state.formErrorMessage.password}
                                            </span>
                                        </div>
                                        <div className="form-group">
                                            <input classname="form-check-input" type="checkbox" value="" id="defaultCheck1" /> Remmeber Me
                                       </div>
                                    </form>
                                    <button type="submit" className="btn btn-primary float-right" name="login"
                                        disabled={!this.state.formValid.buttonActive}>Login</button>
                                </div>
                            </div>
                            <div>
                                <a href="#">Lost your password??</a>
                            </div>
                            <div>
                                <a href="#">
                                    <span class="glyphicon glyphicon-arrow-left"></span>
                                    back to previous page
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment >
        );
    }
}
export default Login;