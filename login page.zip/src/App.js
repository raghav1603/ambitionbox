import React, { Component } from "react";
import { BrowserRouter as Router, Route, Switch, Link,Redirect } from "react-router-dom";
import './App.css';
import login from './components/login'

function App() {
  return (
    <div>
     <nav className="navbar navbar-expand-lg navbar-light  bg-custom">
      {/* <span className="navbar-brand"></span> */}
      {/* <ul className="navbar-nav">
        <li className="nav-item">
          <Link className="nav-link" to="/log"> </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/view"> </Link>
        </li>
      </ul> */}
    </nav>
    <Switch>
            <Route exact path='/login' component={login}/>
        
            
            <Route path='/' render={()=>(<Redirect to='/login'/>)}/>
          </Switch>
    {/* your routing code goes here */}
  </div>
  );
}

export default App;
